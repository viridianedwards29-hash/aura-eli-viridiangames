# Local dependency notices

Particle Clicker includes these locally served libraries so its gameplay does not depend on external CDNs:

- jQuery 2.1.1 — Copyright (c) 2005, 2014 jQuery Foundation, Inc.
- AngularJS 1.3.0-beta.17 — Copyright (c) 2010–2014 Google, Inc.
- Bootstrap JavaScript 3.3.1 — Copyright (c) 2011–2014 Twitter, Inc.

The project's original js/external files are preserved with their embedded license notices. The Bootstrap stylesheet and Glyphicons were included in the original Particle Clicker repository.

Each library listed above is distributed under the MIT License:

Copyright notices above and the following permission notice apply to each listed library.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
