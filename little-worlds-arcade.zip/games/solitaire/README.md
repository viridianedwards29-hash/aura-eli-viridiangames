# Solitaire

A free, simple, web-based collection of solitaire card games — built so it's safe
to hand to anyone, including people who are frequent targets of "your account has
expired, enter your card number" scam popups in ad-supported card game apps.

Three game modes: **Klondike** (the classic), **FreeCell** (almost every deal is
winnable), and **Spider** (build same-suit runs, with 1/2/4-suit difficulty).

## 🔗 Play it: [megahertzok.github.io/solitaire](https://megahertzok.github.io/solitaire/)

Bookmark that link — it's the whole app, right in your browser. Nothing to
install, no account to make.

## About

I built this after watching my grandmother — and I'm sure plenty of other people's
grandparents — get targeted by fake pop-up ads inside "free" solitaire apps. The
scam is always some version of "Your Gmail password has expired" or "Your iCloud
storage is full," dressed up to look like a real system alert, with a form asking
for a credit card number to "fix" it.

Those ads show up because the app is ad-supported, and there's real money in
tricking someone into thinking it's a legitimate message from Apple or Google
instead of an ad. She's not careless — these are deliberately designed to look
official, and they show up while someone is relaxed and playing a casual card
game, not thinking about security. It's a predatory pattern, and older folks who
just want to play a round of solitaire are a common target.

So I built this instead: a plain, boring, completely ad-free solitaire app. No
account, no ads, no in-app purchases, no tracking, nothing trying to sell anything
or scare anyone. Just cards. It's free and open source, so you don't have to take
my word for any of this — anyone can read the code and see for themselves that
there are no hidden network calls, or run their own copy for someone they care
about.

*— Braden*

The app itself has an "About" tab (under **How to Play**) with this same note, and
a "Basics" tab that walks through the controls if solitaire isn't something you
already know how to play.

## What that means in practice

- **No ads.** None, ever — not even "safe" ones.
- **No accounts, no sign-in, no payment forms of any kind.**
- **No tracking, no analytics.**
- **No network requests at all.** Open the page and disconnect from the internet —
  it still works. You can verify this yourself: the whole game is a handful of
  plain files (`index.html`, `style.css`, `common.js`, `klondike.js`, `freecell.js`,
  `spider.js`, `app.js`), with no `<script src="https://...">` tags, no fetch/XHR
  calls, and no third-party analytics snippets.
- **No installation.** It's a webpage, not an app store download.
- **Score is kept, but only for the current session.** It lives in memory while
  the tab is open and resets on New Game or reload — it is never written to
  disk, never sent anywhere, and there's no leaderboard.

## How to play

Click a card to select it (it highlights), then click a destination pile to move
it there. Click the same card again to deselect it. Double-click a card to try
sending it straight to a foundation (Klondike/FreeCell) or to the first open spot
(Spider). **Undo** reverses your last move; **New Game** reshuffles.

### Klondike

- Click the stock pile (top-left) to draw a card to the waste pile.
- Build tableau columns down in alternating colors (e.g. black 7 on red 8).
- Build foundations up by suit, starting from the Ace.
- Only a King (or a run starting with one) can go into an empty column.
- **Draw 1 / Draw 3** switches how many cards are drawn from the stock at once
  (Draw 3 is harder — only the top card of the waste pile is ever playable).
- Scoring (standard "Microsoft" rules): +5 waste→tableau, +10 waste→foundation,
  +10 tableau→foundation, −15 foundation→tableau, +5 for exposing a new
  face-down card. Score never drops below 0.

### FreeCell

- All 52 cards are dealt face up — no stock or waste pile.
- 4 free cells (top-left) each hold one card temporarily.
- Build tableau columns down in alternating colors, same as Klondike, but
  **any** card can start an empty column (not just a King).
- You can move several cards at once if you have enough empty free cells and
  empty columns to support it (a "supermove") — the game checks this for you.
- Scoring: +10 per card reaching a foundation, −15 if one leaves a foundation.

### Spider

- 10 tableau columns, dealt from two decks (104 cards).
- Drop any card on a tableau card ranked one higher, regardless of suit — but
  you can only pick up and move a group of cards if they're already a
  same-suit, consecutive run.
- Click the stock pile to deal a new card onto every column (you can't deal
  while any column is empty).
- Completing a full King-to-Ace run of one suit clears it off the board
  automatically. Win by clearing all 8 runs.
- **Suits** sets the difficulty: 1 suit is easiest, 4 suits is the full/hardest
  game.
- Scoring: starts at 500, −1 per move (including each stock deal), +100 per
  completed run, floor of 0.

## Running it locally

No build step, no dependencies, no installation required:

```bash
git clone https://github.com/megahertzok/solitaire.git
cd solitaire
python3 -m http.server 8000
```

Then open `http://localhost:8000` in a browser. Or just double-click `index.html`.

## Deploying your own copy (GitHub Pages)

1. Fork or clone this repo.
2. In the repo's Settings → Pages, set the source to your default branch, root folder.
3. Your copy will be live at `https://<your-username>.github.io/solitaire/`.

## License

MIT — see [LICENSE](LICENSE). Do whatever you like with it; give it to family,
put it on a Raspberry Pi, whatever keeps someone off a scam popup.
