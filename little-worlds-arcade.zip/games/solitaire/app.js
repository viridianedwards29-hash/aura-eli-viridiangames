"use strict";

/* Wires up mode switching and the shared top bar (New Game / Undo / Score). */

const Controllers = { klondike: Klondike, freecell: FreeCell, spider: Spider };
let activeMode = "klondike";

const boards = {
  klondike: document.getElementById("klondike-board"),
  freecell: document.getElementById("freecell-board"),
  spider: document.getElementById("spider-board"),
};
const optionPanels = {
  klondike: document.getElementById("klondike-options"),
  freecell: null,
  spider: document.getElementById("spider-options"),
};

const scoreValueEl = document.getElementById("score-value");
const undoBtn = document.getElementById("undo-btn");
const winOverlay = document.getElementById("win-overlay");

function updateTopBar() {
  const ctrl = Controllers[activeMode];
  scoreValueEl.textContent = ctrl.getScore();
  undoBtn.disabled = !ctrl.canUndo();
}

function checkWin() {
  if (Controllers[activeMode].isWon()) {
    winOverlay.classList.add("show");
  }
}

function notify() {
  updateTopBar();
  checkWin();
}

function hideWin() {
  winOverlay.classList.remove("show");
}

function switchMode(mode) {
  if (mode === activeMode) return;
  activeMode = mode;
  Object.keys(boards).forEach((m) => {
    boards[m].hidden = m !== mode;
  });
  Object.keys(optionPanels).forEach((m) => {
    if (optionPanels[m]) optionPanels[m].hidden = m !== mode;
  });
  document.querySelectorAll(".mode-tab").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.mode === mode);
  });
  hideWin();
  setMessage("");
  updateTopBar();
}

document.querySelectorAll(".mode-tab").forEach((btn) => {
  btn.addEventListener("click", () => switchMode(btn.dataset.mode));
});

document.getElementById("new-game-btn").addEventListener("click", () => {
  hideWin();
  Controllers[activeMode].newGame();
});
document.getElementById("win-new-game-btn").addEventListener("click", () => {
  hideWin();
  Controllers[activeMode].newGame();
});
undoBtn.addEventListener("click", () => {
  Controllers[activeMode].undo();
});

document.querySelectorAll("#klondike-options .opt-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll("#klondike-options .opt-btn").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    hideWin();
    Klondike.setDrawCount(parseInt(btn.dataset.draw, 10));
  });
});

document.querySelectorAll("#spider-options .opt-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll("#spider-options .opt-btn").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    hideWin();
    Spider.setSuitCount(parseInt(btn.dataset.suits, 10));
  });
});

document.getElementById("help-btn").addEventListener("click", () => {
  HelpPanel.open(activeMode);
});

Klondike.mount(notify);
FreeCell.mount(notify);
Spider.mount(notify);
updateTopBar();

try {
  if (localStorage.getItem("solitaire-hide-help") !== "1") {
    HelpPanel.open("general");
  }
} catch (e) {
  HelpPanel.open("general");
}
