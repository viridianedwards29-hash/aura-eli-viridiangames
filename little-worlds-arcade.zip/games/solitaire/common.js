"use strict";

/* Shared constants and helpers used by every game mode. */

const SUITS = [
  { symbol: "♠", color: "black", name: "Spades" },
  { symbol: "♥", color: "red", name: "Hearts" },
  { symbol: "♦", color: "red", name: "Diamonds" },
  { symbol: "♣", color: "black", name: "Clubs" },
];

const RANK_LABELS = ["", "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];

function shuffle(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function cardColor(card) {
  return SUITS[card.suit].color;
}

function cardLabel(card) {
  return RANK_LABELS[card.rank];
}

function isSameColor(a, b) {
  return cardColor(a) === cardColor(b);
}

function isSameSuit(a, b) {
  return a.suit === b.suit;
}

function topCard(pile) {
  return pile.length ? pile[pile.length - 1] : null;
}

function makeCardEl(card, faceUp) {
  const el = document.createElement("div");
  el.className = "card " + (faceUp ? cardColor(card) : "face-down");
  if (!faceUp) return el;
  const suit = SUITS[card.suit].symbol;
  const label = cardLabel(card);
  el.innerHTML =
    '<div class="corner top">' + label + "<br>" + suit + "</div>" +
    '<div class="center-suit">' + suit + "</div>" +
    '<div class="corner bottom">' + label + "<br>" + suit + "</div>";
  return el;
}

function clearPile(el) {
  Array.from(el.querySelectorAll(".card")).forEach((n) => n.remove());
}

function snapshotState(state) {
  return JSON.parse(JSON.stringify(state));
}

function setMessage(msg) {
  document.getElementById("message").textContent = msg;
}
