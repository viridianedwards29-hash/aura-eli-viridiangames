"use strict";

/*
  FreeCell Solitaire. All 52 cards are dealt face up; there's no stock/waste.
  4 free cells each hold one card temporarily. Any card (or valid sequence,
  limited by a "supermove" capacity) can enter an empty tableau column.
  Score: +10 per card reaching a foundation, -15 if a card leaves a
  foundation. Kept only in memory for this session, never saved or sent
  anywhere.
*/

const FreeCell = (function () {
  const TABLEAU_OFFSET = 28;
  const NUM_COLUMNS = 8;

  let state = null;
  let selection = null; // { source: 'tableau'|'freecell'|'foundation', pileIndex, cardIndex }
  let history = [];
  let notify = () => {};

  function buildDeck() {
    const deck = [];
    for (let s = 0; s < 4; s++) {
      for (let r = 1; r <= 13; r++) {
        deck.push({ suit: s, rank: r, faceUp: true });
      }
    }
    return deck;
  }

  function newGame() {
    const deck = shuffle(buildDeck());
    const tableau = Array.from({ length: NUM_COLUMNS }, () => []);
    deck.forEach((card, i) => tableau[i % NUM_COLUMNS].push(card));
    state = {
      freeCells: [null, null, null, null],
      foundations: [[], [], [], []],
      tableau,
      score: 0,
    };
    selection = null;
    history = [];
    setMessage("");
    render();
    notify();
  }

  function pushHistory() {
    history.push(snapshotState(state));
    if (history.length > 200) history.shift();
  }

  function undo() {
    if (history.length === 0) return;
    state = history.pop();
    selection = null;
    setMessage("");
    render();
    notify();
  }

  function canUndo() {
    return history.length > 0;
  }

  function getScore() {
    return state.score;
  }

  function isWon() {
    return state.foundations.reduce((sum, p) => sum + p.length, 0) === 52;
  }

  function addScore(delta) {
    state.score = Math.max(0, state.score + delta);
  }

  function countEmptyFreeCells() {
    return state.freeCells.filter((c) => c === null).length;
  }

  function countEmptyTableauColumns() {
    return state.tableau.filter((col) => col.length === 0).length;
  }

  function maxMoveSize(destIsEmptyColumn) {
    let ec = countEmptyTableauColumns();
    if (destIsEmptyColumn) ec = Math.max(ec - 1, 0);
    return (1 + countEmptyFreeCells()) * Math.pow(2, ec);
  }

  // ---- Rendering ----

  function render() {
    for (let i = 0; i < 4; i++) renderFreeCell(i);
    for (let i = 0; i < 4; i++) renderFoundation(i);
    for (let i = 0; i < NUM_COLUMNS; i++) renderTableau(i);
  }

  function renderFreeCell(i) {
    const el = document.getElementById("fc-freecell-" + i);
    clearPile(el);
    const card = state.freeCells[i];
    if (card) {
      const c = makeCardEl(card, true);
      if (isSelected("freecell", i, 0)) c.classList.add("selected");
      c.onclick = (e) => {
        e.stopPropagation();
        onCardClick("freecell", i, 0);
      };
      c.ondblclick = (e) => {
        e.stopPropagation();
        tryAutoToFoundation("freecell", i, 0);
      };
      el.appendChild(c);
    }
    el.onclick = () => onPileBackgroundClick("freecell", i);
  }

  function renderFoundation(i) {
    const el = document.getElementById("fc-foundation-" + i);
    clearPile(el);
    const pile = state.foundations[i];
    const card = topCard(pile);
    if (card) {
      const c = makeCardEl(card, true);
      if (isSelected("foundation", i, pile.length - 1)) c.classList.add("selected");
      c.onclick = (e) => {
        e.stopPropagation();
        onCardClick("foundation", i, pile.length - 1);
      };
      el.appendChild(c);
    }
    el.onclick = () => onPileBackgroundClick("foundation", i);
  }

  function renderTableau(i) {
    const el = document.getElementById("fc-tableau-" + i);
    clearPile(el);
    const pile = state.tableau[i];
    pile.forEach((card, idx) => {
      const c = makeCardEl(card, true);
      c.style.top = idx * TABLEAU_OFFSET + "px";
      c.style.zIndex = String(idx);
      if (isSelected("tableau", i, idx)) c.classList.add("selected");
      c.onclick = (e) => {
        e.stopPropagation();
        onCardClick("tableau", i, idx);
      };
      c.ondblclick = (e) => {
        e.stopPropagation();
        tryAutoToFoundation("tableau", i, idx);
      };
      el.appendChild(c);
    });
    const minHeight = Math.max(138, pile.length * TABLEAU_OFFSET + 110);
    el.style.minHeight = minHeight + "px";
    el.onclick = () => onPileBackgroundClick("tableau", i);
  }

  function isSelected(source, pileIndex, cardIndex) {
    if (!selection) return false;
    if (selection.source !== source || selection.pileIndex !== pileIndex) return false;
    if (source === "tableau") return cardIndex >= selection.cardIndex;
    return cardIndex === selection.cardIndex;
  }

  // ---- Interaction ----

  function onPileBackgroundClick(source, pileIndex) {
    if (selection) {
      attemptMove(source, pileIndex);
    } else {
      selection = null;
      render();
    }
  }

  function onCardClick(source, pileIndex, cardIndex) {
    if (!selection) {
      trySelect(source, pileIndex, cardIndex);
      render();
      return;
    }
    if (
      selection.source === source &&
      selection.pileIndex === pileIndex &&
      selection.cardIndex === cardIndex
    ) {
      selection = null;
      render();
      return;
    }
    const moved = attemptMove(source, pileIndex);
    if (!moved) {
      trySelect(source, pileIndex, cardIndex);
      render();
    }
  }

  function trySelect(source, pileIndex, cardIndex) {
    if (source === "freecell" || source === "foundation") {
      selection = { source, pileIndex, cardIndex };
      return;
    }
    if (source === "tableau") {
      const pile = state.tableau[pileIndex];
      for (let k = cardIndex; k < pile.length - 1; k++) {
        const a = pile[k];
        const b = pile[k + 1];
        if (isSameColor(a, b) || a.rank !== b.rank + 1) return;
      }
      selection = { source, pileIndex, cardIndex };
    }
  }

  function getSelectedCards() {
    if (!selection) return [];
    if (selection.source === "tableau") return state.tableau[selection.pileIndex].slice(selection.cardIndex);
    if (selection.source === "freecell") return state.freeCells[selection.pileIndex] ? [state.freeCells[selection.pileIndex]] : [];
    if (selection.source === "foundation") return state.foundations[selection.pileIndex].slice(selection.cardIndex);
    return [];
  }

  function removeSelectedCards() {
    if (selection.source === "tableau") {
      return state.tableau[selection.pileIndex].splice(selection.cardIndex);
    }
    if (selection.source === "freecell") {
      const card = state.freeCells[selection.pileIndex];
      state.freeCells[selection.pileIndex] = null;
      return [card];
    }
    if (selection.source === "foundation") {
      return state.foundations[selection.pileIndex].splice(selection.cardIndex);
    }
    return [];
  }

  function canPlaceOnFoundation(card, foundationPile) {
    const top = topCard(foundationPile);
    if (!top) return card.rank === 1;
    return card.suit === top.suit && card.rank === top.rank + 1;
  }

  function canPlaceOnTableau(card, tableauPile) {
    const top = topCard(tableauPile);
    if (!top) return true; // any card may start an empty column in FreeCell
    return !isSameColor(card, top) && card.rank === top.rank - 1;
  }

  function attemptMove(destSource, destPileIndex) {
    if (!selection) return false;
    const cards = getSelectedCards();
    if (cards.length === 0) return false;
    const srcSource = selection.source;

    if (destSource === "foundation") {
      if (cards.length !== 1) {
        setMessage("Only one card at a time can go to a foundation.");
        return false;
      }
      if (srcSource === "foundation" && selection.pileIndex === destPileIndex) return false;
      const pile = state.foundations[destPileIndex];
      if (!canPlaceOnFoundation(cards[0], pile)) {
        setMessage("That card can't go there.");
        return false;
      }
      pushHistory();
      removeSelectedCards();
      pile.push(cards[0]);
      addScore(10);
      finishMove();
      return true;
    }

    if (destSource === "freecell") {
      if (cards.length !== 1) {
        setMessage("Only one card at a time can go to a free cell.");
        return false;
      }
      if (srcSource === "freecell" && selection.pileIndex === destPileIndex) return false;
      if (state.freeCells[destPileIndex] !== null) {
        setMessage("That free cell is occupied.");
        return false;
      }
      pushHistory();
      removeSelectedCards();
      state.freeCells[destPileIndex] = cards[0];
      finishMove();
      return true;
    }

    if (destSource === "tableau") {
      if (srcSource === "tableau" && selection.pileIndex === destPileIndex) return false;
      const pile = state.tableau[destPileIndex];
      const destIsEmpty = pile.length === 0;
      if (!canPlaceOnTableau(cards[0], pile)) {
        setMessage("That card can't go there.");
        return false;
      }
      const limit = maxMoveSize(destIsEmpty);
      if (cards.length > limit) {
        setMessage(
          "Not enough free cells/open columns to move " + cards.length + " cards at once (max " + limit + ")."
        );
        return false;
      }
      pushHistory();
      removeSelectedCards();
      cards.forEach((c) => pile.push(c));
      if (srcSource === "foundation") addScore(-15);
      finishMove();
      return true;
    }

    return false;
  }

  function tryAutoToFoundation(source, pileIndex, cardIndex) {
    const isTopOfPile =
      (source === "tableau" && cardIndex === state.tableau[pileIndex].length - 1) ||
      source === "freecell";
    if (!isTopOfPile) return;

    const card = source === "tableau" ? state.tableau[pileIndex][cardIndex] : state.freeCells[pileIndex];
    if (!card) return;

    for (let f = 0; f < 4; f++) {
      if (canPlaceOnFoundation(card, state.foundations[f])) {
        pushHistory();
        if (source === "tableau") {
          state.tableau[pileIndex].pop();
        } else {
          state.freeCells[pileIndex] = null;
        }
        state.foundations[f].push(card);
        addScore(10);
        selection = null;
        finishMove();
        return;
      }
    }
  }

  function finishMove() {
    selection = null;
    setMessage("");
    render();
    notify();
  }

  function mount(notifyFn) {
    notify = notifyFn;
    newGame();
  }

  return { mount, newGame, undo, canUndo, getScore, isWon };
})();
