"use strict";

/* Builds the "How to Play" panel content, with small rendered card examples
   reusing makeCardEl() from common.js. Pure presentation — no game state. */

const HelpPanel = (function () {
  // suit indices from common.js: 0 spades(black) 1 hearts(red) 2 diamonds(red) 3 clubs(black)
  const S = 0, H = 1, D = 2, C = 3;

  function miniCard(suit, rank) {
    const el = makeCardEl({ suit, rank }, true);
    el.classList.add("help-card");
    el.style.position = "relative";
    return el;
  }

  function arrow(label) {
    const span = document.createElement("span");
    span.className = "example-arrow";
    span.textContent = label || "→";
    return span;
  }

  function text(str, cls) {
    const span = document.createElement("span");
    if (cls) span.className = cls;
    span.textContent = str;
    return span;
  }

  // items: array of {suit,rank} or the string "arrow" or {label:'...'} for a text arrow
  function exampleBlock({ title, items, stack, caption, valid }) {
    const wrap = document.createElement("div");
    wrap.className = "example-block";
    if (title) {
      const h = document.createElement("div");
      h.className = "example-title";
      h.textContent = title;
      wrap.appendChild(h);
    }
    const stage = document.createElement("div");
    stage.className = "example-stage" + (stack ? " example-stack" : " example-row");
    let stackIndex = 0;
    items.forEach((item) => {
      if (item === "arrow") {
        stage.appendChild(arrow());
        return;
      }
      if (item && item.label) {
        stage.appendChild(arrow(item.label));
        return;
      }
      const el = miniCard(item.suit, item.rank);
      if (stack) {
        el.style.marginTop = stackIndex === 0 ? "0" : "-50px";
        el.style.marginLeft = stackIndex * 16 + "px";
        stackIndex++;
      }
      stage.appendChild(el);
    });
    wrap.appendChild(stage);
    if (caption) {
      const cap = document.createElement("div");
      cap.className = "example-caption" + (valid === true ? " valid" : valid === false ? " invalid" : "");
      cap.textContent = (valid === true ? "✓ " : valid === false ? "✗ " : "") + caption;
      wrap.appendChild(cap);
    }
    return wrap;
  }

  function paragraph(str) {
    const p = document.createElement("p");
    p.textContent = str;
    return p;
  }

  function heading(str) {
    const h = document.createElement("h3");
    h.textContent = str;
    return h;
  }

  function list(items) {
    const ul = document.createElement("ul");
    items.forEach((i) => {
      const li = document.createElement("li");
      li.textContent = i;
      ul.appendChild(li);
    });
    return ul;
  }

  function buildGeneral() {
    const frag = document.createDocumentFragment();
    frag.appendChild(paragraph(
      "All three games use the same basic controls, so once you know these you can play any of them."
    ));
    frag.appendChild(list([
      "Click a card to pick it up — it gets a yellow glow.",
      "Click a destination pile to drop the card there.",
      "Click the same card again to put it back down without moving it.",
      "Double-click a card to try sending it somewhere useful automatically.",
      "“New Game” starts over. “Undo” takes back your last move — as many times as you want.",
      "The score is just for fun. It only exists while this page is open — closing or refreshing resets it, and it's never saved to your computer or sent anywhere.",
    ]));
    frag.appendChild(paragraph("Pick a tab above (Klondike, FreeCell, or Spider) to see that game's specific rules with examples."));
    return frag;
  }

  function buildKlondike() {
    const frag = document.createDocumentFragment();
    frag.appendChild(paragraph(
      "The goal: move every card onto the four foundation piles (top right), one pile per suit, built up in order from the Ace to the King."
    ));

    frag.appendChild(heading("Stacking cards in the columns"));
    frag.appendChild(paragraph("In the 7 columns below, you can stack a card onto another card that is one rank higher and the opposite color."));
    frag.appendChild(exampleBlock({
      items: [{ suit: C, rank: 7 }, "arrow", { suit: H, rank: 6 }],
      caption: "black 7 can hold a red 6",
      valid: true,
    }));
    frag.appendChild(exampleBlock({
      items: [{ suit: C, rank: 7 }, "arrow", { suit: S, rank: 6 }],
      caption: "black 7 can't hold a black 6 — wrong color",
      valid: false,
    }));

    frag.appendChild(heading("Building a foundation"));
    frag.appendChild(paragraph("Each foundation pile starts empty and only accepts the Ace of its suit first, then builds upward, same suit only."));
    frag.appendChild(exampleBlock({
      items: [{ suit: H, rank: 1 }, { suit: H, rank: 2 }, { suit: H, rank: 3 }],
      caption: "Ace, 2, 3 of hearts, in order",
      valid: true,
    }));

    frag.appendChild(heading("The stock and waste piles"));
    frag.appendChild(paragraph(
      "Click the stock pile (top-left) to flip cards into the waste pile next to it. Only the top card of the waste pile can be played. " +
      "“Draw 1” flips one card at a time; “Draw 3” flips three at once (harder, since two of them get buried)."
    ));

    frag.appendChild(heading("Empty columns"));
    frag.appendChild(paragraph("Only a King (or a stack starting with one) can be placed into a column with nothing in it."));

    return frag;
  }

  function buildFreeCell() {
    const frag = document.createDocumentFragment();
    frag.appendChild(paragraph(
      "Same goal as Klondike — get every card onto the four foundations, by suit, from Ace up to King. " +
      "The difference: every card is dealt face up right at the start, so there's no luck involved in what's hidden — almost every FreeCell deal can be won with enough thinking."
    ));

    frag.appendChild(heading("Free cells"));
    frag.appendChild(paragraph(
      "The 4 boxes in the top-left are “free cells” — each can temporarily hold exactly one card, like a spot to set a card down while you rearrange things."
    ));
    frag.appendChild(exampleBlock({
      items: [{ suit: D, rank: 9 }],
      caption: "one card parked in a free cell",
      valid: null,
    }));

    frag.appendChild(heading("Stacking cards in the columns"));
    frag.appendChild(paragraph("Same rule as Klondike: stack a card onto another that's one rank higher and the opposite color."));
    frag.appendChild(exampleBlock({
      items: [{ suit: S, rank: 9 }, "arrow", { suit: D, rank: 8 }],
      caption: "black 9 can hold a red 8",
      valid: true,
    }));

    frag.appendChild(heading("Empty columns work differently here"));
    frag.appendChild(paragraph("Unlike Klondike, ANY card can start an empty column in FreeCell — not just a King."));
    frag.appendChild(exampleBlock({
      items: [{ suit: D, rank: 5 }],
      caption: "a lone 5 can start an empty column",
      valid: true,
    }));

    frag.appendChild(heading("Moving several cards at once"));
    frag.appendChild(paragraph(
      "You can drag a whole stacked run at once, but only if you have enough empty free cells and empty columns free to support it — " +
      "the game checks this automatically and will tell you if a move is too big."
    ));

    return frag;
  }

  function buildSpider() {
    const frag = document.createDocumentFragment();
    frag.appendChild(paragraph(
      "The goal: build 8 complete runs of one suit, King down to Ace, in order. A completed run clears itself off the board automatically — there are no foundation piles to move cards to by hand."
    ));

    frag.appendChild(heading("Dropping a card"));
    frag.appendChild(paragraph("You can drop any card onto a tableau card that's exactly one rank higher — suit and color don't matter here."));
    frag.appendChild(exampleBlock({
      items: [{ suit: S, rank: 9 }, "arrow", { suit: H, rank: 8 }],
      caption: "black 9 can hold a red 8 — any suit works",
      valid: true,
    }));

    frag.appendChild(heading("Moving a group of cards"));
    frag.appendChild(paragraph(
      "You can only pick up and move several cards together if they're already sitting in a row of the same suit, in order."
    ));
    frag.appendChild(exampleBlock({
      items: [{ suit: H, rank: 9 }, { suit: H, rank: 8 }, { suit: H, rank: 7 }],
      stack: true,
      caption: "9-8-7 of hearts can move as one group",
      valid: true,
    }));
    frag.appendChild(exampleBlock({
      items: [{ suit: H, rank: 9 }, { suit: S, rank: 8 }],
      stack: true,
      caption: "9 of hearts + 8 of spades can't move together — different suits",
      valid: false,
    }));

    frag.appendChild(heading("The stock pile"));
    frag.appendChild(paragraph(
      "Click the stock pile (top-left) to deal one new card face-up onto every column at once. " +
      "You can't do this while any column is completely empty."
    ));

    frag.appendChild(heading("Difficulty"));
    frag.appendChild(paragraph(
      "The “Suits” setting controls how many different suits are in the deck: 1 suit is the easiest way to learn, 4 suits is the full, hardest game."
    ));

    return frag;
  }

  function buildAbout() {
    const frag = document.createDocumentFragment();
    frag.appendChild(paragraph(
      "I built this after watching my grandmother — and I'm sure plenty of other people's grandparents — " +
      "get targeted by fake pop-up ads inside “free” solitaire apps. The scam is always some version of " +
      "“Your Gmail password has expired” or “Your iCloud storage is full,” dressed up to look like a " +
      "real system alert, with a form asking for a credit card number to “fix” it."
    ));
    frag.appendChild(paragraph(
      "Those ads show up because the app is ad-supported, and there's real money in tricking someone into " +
      "thinking it's a legitimate message from Apple or Google instead of an ad. She's not careless — these " +
      "are deliberately designed to look official, and they show up while someone is relaxed and playing a " +
      "casual card game, not thinking about security. It's a predatory pattern, and older folks who just want " +
      "to play a round of solitaire are a common target."
    ));
    frag.appendChild(paragraph(
      "So I built this instead: a plain, boring, completely ad-free solitaire app. No account, no ads, no " +
      "in-app purchases, no tracking, nothing trying to sell anything or scare anyone. Just cards."
    ));
    frag.appendChild(paragraph(
      "It's free and open source, so you don't have to take my word for any of this — anyone can read the " +
      "code and see for themselves that there are no hidden network calls, or run their own copy for someone " +
      "they care about."
    ));
    const sig = document.createElement("p");
    sig.className = "about-signature";
    sig.textContent = "— Braden";
    frag.appendChild(sig);
    return frag;
  }

  const BUILDERS = {
    general: buildGeneral,
    klondike: buildKlondike,
    freecell: buildFreeCell,
    spider: buildSpider,
    about: buildAbout,
  };

  function showTab(key) {
    const content = document.getElementById("help-content");
    content.innerHTML = "";
    content.appendChild(BUILDERS[key]());
    document.querySelectorAll(".help-tab").forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.help === key);
    });
    content.scrollTop = 0;
  }

  function open(key) {
    showTab(key || "general");
    document.getElementById("help-overlay").classList.add("show");
  }

  function close() {
    document.getElementById("help-overlay").classList.remove("show");
  }

  document.querySelectorAll(".help-tab").forEach((btn) => {
    btn.addEventListener("click", () => showTab(btn.dataset.help));
  });
  document.getElementById("help-close").addEventListener("click", close);
  document.getElementById("help-got-it").addEventListener("click", () => {
    const checkbox = document.getElementById("help-dontshow-checkbox");
    if (checkbox.checked) {
      try { localStorage.setItem("solitaire-hide-help", "1"); } catch (e) { /* ignore */ }
    }
    close();
  });
  document.getElementById("help-overlay").addEventListener("click", (e) => {
    if (e.target.id === "help-overlay") close();
  });

  return { open, close, showTab };
})();
