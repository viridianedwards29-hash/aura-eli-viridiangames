"use strict";

/*
  Klondike Solitaire.
  Standard ("Microsoft") scoring: +5 waste->tableau, +10 waste->foundation,
  +10 tableau->foundation, -15 foundation->tableau, +5 for exposing a new
  face-down tableau card. Score is kept only in memory for this game session
  and is never saved or sent anywhere.
*/

const Klondike = (function () {
  const TABLEAU_OFFSET = 28;

  let state = null;
  let selection = null; // { source: 'tableau'|'waste'|'foundation', pileIndex, cardIndex }
  let history = [];
  let drawCount = 1;
  let notify = () => {};

  function buildDeck() {
    const deck = [];
    for (let s = 0; s < 4; s++) {
      for (let r = 1; r <= 13; r++) {
        deck.push({ suit: s, rank: r, faceUp: false });
      }
    }
    return deck;
  }

  function newGame() {
    const deck = shuffle(buildDeck());
    const tableau = [[], [], [], [], [], [], []];
    for (let col = 0; col < 7; col++) {
      for (let row = 0; row <= col; row++) {
        const card = deck.pop();
        card.faceUp = row === col;
        tableau[col].push(card);
      }
    }
    state = {
      stock: deck.map((c) => ({ ...c, faceUp: false })),
      waste: [],
      foundations: [[], [], [], []],
      tableau,
      score: 0,
    };
    selection = null;
    history = [];
    setMessage("");
    render();
    notify();
  }

  function setDrawCount(n) {
    drawCount = n;
    newGame();
  }

  function pushHistory() {
    history.push(snapshotState(state));
    if (history.length > 200) history.shift();
  }

  function undo() {
    if (history.length === 0) return;
    state = history.pop();
    selection = null;
    setMessage("");
    render();
    notify();
  }

  function canUndo() {
    return history.length > 0;
  }

  function getScore() {
    return state.score;
  }

  function isWon() {
    return state.foundations.reduce((sum, p) => sum + p.length, 0) === 52;
  }

  function addScore(delta) {
    state.score = Math.max(0, state.score + delta);
  }

  // ---- Rendering ----

  function render() {
    renderStock();
    renderWaste();
    for (let i = 0; i < 4; i++) renderFoundation(i);
    for (let i = 0; i < 7; i++) renderTableau(i);
  }

  function renderStock() {
    const el = document.getElementById("kd-stock-pile");
    clearPile(el);
    if (state.stock.length) {
      el.appendChild(makeCardEl(null, false));
    }
    el.onclick = onStockClick;
  }

  function renderWaste() {
    const el = document.getElementById("kd-waste-pile");
    clearPile(el);
    const card = topCard(state.waste);
    if (card) {
      const c = makeCardEl(card, true);
      if (isSelected("waste", 0, state.waste.length - 1)) c.classList.add("selected");
      c.onclick = (e) => {
        e.stopPropagation();
        onCardClick("waste", 0, state.waste.length - 1);
      };
      c.ondblclick = (e) => {
        e.stopPropagation();
        tryAutoToFoundation("waste", 0, state.waste.length - 1);
      };
      el.appendChild(c);
    }
    el.onclick = () => onPileBackgroundClick("waste", 0);
  }

  function renderFoundation(i) {
    const el = document.getElementById("kd-foundation-" + i);
    clearPile(el);
    const pile = state.foundations[i];
    const card = topCard(pile);
    if (card) {
      const c = makeCardEl(card, true);
      if (isSelected("foundation", i, pile.length - 1)) c.classList.add("selected");
      c.onclick = (e) => {
        e.stopPropagation();
        onCardClick("foundation", i, pile.length - 1);
      };
      el.appendChild(c);
    }
    el.onclick = () => onPileBackgroundClick("foundation", i);
  }

  function renderTableau(i) {
    const el = document.getElementById("kd-tableau-" + i);
    clearPile(el);
    const pile = state.tableau[i];
    pile.forEach((card, idx) => {
      const c = makeCardEl(card, card.faceUp);
      c.style.top = idx * TABLEAU_OFFSET + "px";
      c.style.zIndex = String(idx);
      if (card.faceUp) {
        if (isSelected("tableau", i, idx)) c.classList.add("selected");
        c.onclick = (e) => {
          e.stopPropagation();
          onCardClick("tableau", i, idx);
        };
        c.ondblclick = (e) => {
          e.stopPropagation();
          tryAutoToFoundation("tableau", i, idx);
        };
      }
      el.appendChild(c);
    });
    const minHeight = Math.max(138, pile.length * TABLEAU_OFFSET + 110);
    el.style.minHeight = minHeight + "px";
    el.onclick = () => onPileBackgroundClick("tableau", i);
  }

  function isSelected(source, pileIndex, cardIndex) {
    if (!selection) return false;
    if (selection.source !== source || selection.pileIndex !== pileIndex) return false;
    if (source === "tableau") return cardIndex >= selection.cardIndex;
    return cardIndex === selection.cardIndex;
  }

  // ---- Interaction ----

  function onStockClick() {
    selection = null;
    if (state.stock.length > 0) {
      pushHistory();
      const n = Math.min(drawCount, state.stock.length);
      for (let i = 0; i < n; i++) {
        const card = state.stock.pop();
        card.faceUp = true;
        state.waste.push(card);
      }
    } else if (state.waste.length > 0) {
      pushHistory();
      while (state.waste.length) {
        const card = state.waste.pop();
        card.faceUp = false;
        state.stock.push(card);
      }
    }
    setMessage("");
    render();
    notify();
  }

  function onPileBackgroundClick(source, pileIndex) {
    if (selection) {
      attemptMove(source, pileIndex);
    } else {
      selection = null;
      render();
    }
  }

  function onCardClick(source, pileIndex, cardIndex) {
    if (!selection) {
      trySelect(source, pileIndex, cardIndex);
      render();
      return;
    }
    if (
      selection.source === source &&
      selection.pileIndex === pileIndex &&
      selection.cardIndex === cardIndex
    ) {
      selection = null;
      render();
      return;
    }
    const moved = attemptMove(source, pileIndex);
    if (!moved) {
      trySelect(source, pileIndex, cardIndex);
      render();
    }
  }

  function trySelect(source, pileIndex, cardIndex) {
    if (source === "waste" || source === "foundation") {
      selection = { source, pileIndex, cardIndex };
      return;
    }
    if (source === "tableau") {
      const pile = state.tableau[pileIndex];
      const card = pile[cardIndex];
      if (!card.faceUp) return;
      for (let k = cardIndex; k < pile.length - 1; k++) {
        const a = pile[k];
        const b = pile[k + 1];
        if (!a.faceUp || !b.faceUp) return;
        if (isSameColor(a, b) || a.rank !== b.rank + 1) return;
      }
      selection = { source, pileIndex, cardIndex };
    }
  }

  function getSelectedCards() {
    if (!selection) return [];
    if (selection.source === "tableau") return state.tableau[selection.pileIndex].slice(selection.cardIndex);
    if (selection.source === "waste") return state.waste.slice(selection.cardIndex);
    if (selection.source === "foundation") return state.foundations[selection.pileIndex].slice(selection.cardIndex);
    return [];
  }

  function removeSelectedCards() {
    if (selection.source === "tableau") {
      const pile = state.tableau[selection.pileIndex];
      const removed = pile.splice(selection.cardIndex);
      let flipped = false;
      if (pile.length > 0 && !pile[pile.length - 1].faceUp) {
        pile[pile.length - 1].faceUp = true;
        flipped = true;
      }
      return { removed, flipped };
    }
    if (selection.source === "waste") {
      return { removed: state.waste.splice(selection.cardIndex), flipped: false };
    }
    if (selection.source === "foundation") {
      return { removed: state.foundations[selection.pileIndex].splice(selection.cardIndex), flipped: false };
    }
    return { removed: [], flipped: false };
  }

  function canPlaceOnFoundation(card, foundationPile) {
    const top = topCard(foundationPile);
    if (!top) return card.rank === 1;
    return card.suit === top.suit && card.rank === top.rank + 1;
  }

  function canPlaceOnTableau(card, tableauPile) {
    const top = topCard(tableauPile);
    if (!top) return card.rank === 13;
    return !isSameColor(card, top) && card.rank === top.rank - 1;
  }

  function attemptMove(destSource, destPileIndex) {
    if (!selection) return false;
    const cards = getSelectedCards();
    if (cards.length === 0) return false;
    const srcSource = selection.source;

    if (destSource === "foundation") {
      if (cards.length !== 1) {
        setMessage("Only one card at a time can go to a foundation.");
        return false;
      }
      if (srcSource === "foundation" && selection.pileIndex === destPileIndex) return false;
      const pile = state.foundations[destPileIndex];
      if (!canPlaceOnFoundation(cards[0], pile)) {
        setMessage("That card can't go there.");
        return false;
      }
      pushHistory();
      removeSelectedCards();
      pile.push(cards[0]);
      addScore(srcSource === "waste" ? 10 : 10);
      finishMove();
      return true;
    }

    if (destSource === "tableau") {
      if (srcSource === "tableau" && selection.pileIndex === destPileIndex) return false;
      const pile = state.tableau[destPileIndex];
      if (!canPlaceOnTableau(cards[0], pile)) {
        setMessage("That card can't go there.");
        return false;
      }
      pushHistory();
      const { flipped } = removeSelectedCards();
      cards.forEach((c) => pile.push(c));
      if (srcSource === "waste") addScore(5);
      if (srcSource === "foundation") addScore(-15);
      if (flipped) addScore(5);
      finishMove();
      return true;
    }

    return false;
  }

  function tryAutoToFoundation(source, pileIndex, cardIndex) {
    const isTopOfPile =
      (source === "tableau" && cardIndex === state.tableau[pileIndex].length - 1) ||
      (source === "waste" && cardIndex === state.waste.length - 1);
    if (!isTopOfPile) return;

    const card = source === "tableau" ? state.tableau[pileIndex][cardIndex] : state.waste[cardIndex];

    for (let f = 0; f < 4; f++) {
      if (canPlaceOnFoundation(card, state.foundations[f])) {
        pushHistory();
        let flipped = false;
        if (source === "tableau") {
          const pile = state.tableau[pileIndex];
          pile.pop();
          if (pile.length > 0 && !pile[pile.length - 1].faceUp) {
            pile[pile.length - 1].faceUp = true;
            flipped = true;
          }
        } else {
          state.waste.pop();
        }
        state.foundations[f].push(card);
        addScore(source === "waste" ? 10 : 10);
        if (flipped) addScore(5);
        selection = null;
        finishMove();
        return;
      }
    }
  }

  function finishMove() {
    selection = null;
    setMessage("");
    render();
    notify();
  }

  function mount(notifyFn) {
    notify = notifyFn;
    newGame();
  }

  return { mount, newGame, undo, canUndo, getScore, isWon, setDrawCount };
})();
