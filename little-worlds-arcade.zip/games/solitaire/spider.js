"use strict";

/*
  Spider Solitaire. Two decks (104 cards) dealt into 10 columns; the rest
  form the stock, dealt out 10 at a time (one per column). Cards can be
  dropped onto any tableau card ranked one higher regardless of suit, but
  only an already-continuous same-suit run can be picked up and moved as a
  group. Completing a full King-to-Ace run of one suit removes it from play.
  Scoring (matches the common convention): start at 500, -1 per move
  (including each stock deal), +100 per completed sequence, floor of 0.
  Kept only in memory for this session, never saved or sent anywhere.
*/

const Spider = (function () {
  const NUM_COLUMNS = 10;

  let state = null;
  let selection = null; // { pileIndex, cardIndex }
  let history = [];
  let suitCount = 2;
  let notify = () => {};

  function buildDeck(count) {
    let suitsToUse, copiesPerSuit;
    if (count === 1) {
      suitsToUse = [0];
      copiesPerSuit = 8;
    } else if (count === 2) {
      suitsToUse = [0, 1];
      copiesPerSuit = 4;
    } else {
      suitsToUse = [0, 1, 2, 3];
      copiesPerSuit = 2;
    }
    const deck = [];
    suitsToUse.forEach((s) => {
      for (let copy = 0; copy < copiesPerSuit; copy++) {
        for (let r = 1; r <= 13; r++) deck.push({ suit: s, rank: r, faceUp: false });
      }
    });
    return deck;
  }

  function newGame() {
    const deck = shuffle(buildDeck(suitCount));
    const tableau = Array.from({ length: NUM_COLUMNS }, () => []);
    for (let col = 0; col < NUM_COLUMNS; col++) {
      const count = col < 4 ? 6 : 5;
      for (let row = 0; row < count; row++) {
        const card = deck.pop();
        card.faceUp = row === count - 1;
        tableau[col].push(card);
      }
    }
    state = {
      stock: deck, // remaining 50, face down
      tableau,
      completed: [], // array of suit indices, one per finished sequence
      score: 500,
    };
    selection = null;
    history = [];
    setMessage("");
    render();
    notify();
  }

  function setSuitCount(n) {
    suitCount = n;
    newGame();
  }

  function pushHistory() {
    history.push(snapshotState(state));
    if (history.length > 200) history.shift();
  }

  function undo() {
    if (history.length === 0) return;
    state = history.pop();
    selection = null;
    setMessage("");
    render();
    notify();
  }

  function canUndo() {
    return history.length > 0;
  }

  function getScore() {
    return state.score;
  }

  function isWon() {
    return state.completed.length === 8;
  }

  function addScore(delta) {
    state.score = Math.max(0, state.score + delta);
  }

  // ---- Rendering ----

  function render() {
    renderStock();
    for (let i = 0; i < NUM_COLUMNS; i++) renderTableau(i);
    const completedEl = document.getElementById("sp-completed-count");
    if (completedEl) completedEl.textContent = state.completed.length + " / 8";
  }

  function tableauOffset() {
    const v = getComputedStyle(document.getElementById("spider-board")).getPropertyValue("--offset");
    const n = parseFloat(v);
    return isNaN(n) ? 22 : n;
  }

  function renderStock() {
    const el = document.getElementById("sp-stock-pile");
    clearPile(el);
    if (state.stock.length > 0) {
      el.appendChild(makeCardEl(null, false));
    }
    el.onclick = onStockClick;
    const countEl = document.getElementById("sp-stock-count");
    if (countEl) {
      const deals = Math.ceil(state.stock.length / NUM_COLUMNS);
      countEl.textContent = deals + (deals === 1 ? " deal left" : " deals left");
    }
  }

  function renderTableau(i) {
    const el = document.getElementById("sp-tableau-" + i);
    clearPile(el);
    const pile = state.tableau[i];
    const offset = tableauOffset();
    pile.forEach((card, idx) => {
      const c = makeCardEl(card, card.faceUp);
      c.style.top = idx * offset + "px";
      c.style.zIndex = String(idx);
      if (card.faceUp) {
        if (isSelected(i, idx)) c.classList.add("selected");
        c.onclick = (e) => {
          e.stopPropagation();
          onCardClick(i, idx);
        };
        c.ondblclick = (e) => {
          e.stopPropagation();
          autoMove(i, idx);
        };
      }
      el.appendChild(c);
    });
    const cardH = parseFloat(getComputedStyle(el).getPropertyValue("--card-h")) || 138;
    const minHeight = Math.max(cardH, pile.length * offset + cardH - offset + 20);
    el.style.minHeight = minHeight + "px";
    el.onclick = () => onPileBackgroundClick(i);
  }

  function isSelected(pileIndex, cardIndex) {
    if (!selection) return false;
    if (selection.pileIndex !== pileIndex) return false;
    return cardIndex >= selection.cardIndex;
  }

  // ---- Interaction ----

  function onStockClick() {
    selection = null;
    if (state.stock.length === 0) {
      render();
      return;
    }
    if (state.tableau.some((col) => col.length === 0)) {
      setMessage("You can't deal from the stock while a column is empty.");
      render();
      return;
    }
    pushHistory();
    const n = Math.min(NUM_COLUMNS, state.stock.length);
    for (let i = 0; i < n; i++) {
      const card = state.stock.pop();
      card.faceUp = true;
      state.tableau[i].push(card);
    }
    addScore(-1);
    checkCompletions();
    setMessage("");
    render();
    notify();
  }

  function onPileBackgroundClick(pileIndex) {
    if (selection) {
      attemptMove(pileIndex);
    } else {
      selection = null;
      render();
    }
  }

  function onCardClick(pileIndex, cardIndex) {
    if (!selection) {
      trySelect(pileIndex, cardIndex);
      render();
      return;
    }
    if (selection.pileIndex === pileIndex && selection.cardIndex === cardIndex) {
      selection = null;
      render();
      return;
    }
    const moved = attemptMove(pileIndex);
    if (!moved) {
      trySelect(pileIndex, cardIndex);
      render();
    }
  }

  function isValidGrab(pile, cardIndex) {
    if (cardIndex === pile.length - 1) return true; // top card is always graspable alone
    for (let k = cardIndex; k < pile.length - 1; k++) {
      const a = pile[k];
      const b = pile[k + 1];
      if (!a.faceUp || !b.faceUp) return false;
      if (!isSameSuit(a, b) || a.rank !== b.rank + 1) return false;
    }
    return true;
  }

  function trySelect(pileIndex, cardIndex) {
    const pile = state.tableau[pileIndex];
    const card = pile[cardIndex];
    if (!card || !card.faceUp) return;
    if (!isValidGrab(pile, cardIndex)) return;
    selection = { pileIndex, cardIndex };
  }

  function getSelectedCards() {
    if (!selection) return [];
    return state.tableau[selection.pileIndex].slice(selection.cardIndex);
  }

  function canPlaceOnTableau(card, tableauPile) {
    const top = topCard(tableauPile);
    if (!top) return true;
    return card.rank === top.rank - 1;
  }

  function attemptMove(destPileIndex) {
    if (!selection) return false;
    if (selection.pileIndex === destPileIndex) return false;
    const cards = getSelectedCards();
    if (cards.length === 0) return false;
    const destPile = state.tableau[destPileIndex];
    if (!canPlaceOnTableau(cards[0], destPile)) {
      setMessage("That card can't go there.");
      return false;
    }
    pushHistory();
    const srcPile = state.tableau[selection.pileIndex];
    srcPile.splice(selection.cardIndex);
    if (srcPile.length > 0 && !srcPile[srcPile.length - 1].faceUp) {
      srcPile[srcPile.length - 1].faceUp = true;
    }
    cards.forEach((c) => destPile.push(c));
    addScore(-1);
    checkCompletions();
    finishMove();
    return true;
  }

  function autoMove(pileIndex, cardIndex) {
    const pile = state.tableau[pileIndex];
    if (!isValidGrab(pile, cardIndex)) {
      setMessage("Those cards aren't a movable run.");
      return;
    }
    selection = { pileIndex, cardIndex };
    for (let j = 0; j < NUM_COLUMNS; j++) {
      if (j === pileIndex) continue;
      if (attemptMove(j)) return;
    }
    selection = null;
    setMessage("No open spot for that card right now.");
    render();
  }

  function checkCompletions() {
    for (let i = 0; i < NUM_COLUMNS; i++) {
      const pile = state.tableau[i];
      while (pile.length >= 13) {
        const run = pile.slice(pile.length - 13);
        let ok = true;
        for (let k = 0; k < 13; k++) {
          const c = run[k];
          if (!c.faceUp || c.rank !== 13 - k || c.suit !== run[0].suit) {
            ok = false;
            break;
          }
        }
        if (!ok) break;
        pile.splice(pile.length - 13, 13);
        state.completed.push(run[0].suit);
        addScore(100);
        if (pile.length > 0 && !pile[pile.length - 1].faceUp) {
          pile[pile.length - 1].faceUp = true;
        }
      }
    }
  }

  function finishMove() {
    selection = null;
    setMessage("");
    render();
    notify();
  }

  function mount(notifyFn) {
    notify = notifyFn;
    newGame();
  }

  return { mount, newGame, undo, canUndo, getScore, isWon, setSuitCount };
})();
