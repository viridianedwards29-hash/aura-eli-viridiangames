# Meme Machine sound credits

The six recorded voice clips in `sfx/` are from **Silly Sound Effects** by
EZduzziteh, published on OpenGameArt under the CC0 1.0 Universal dedication.
They are bundled locally so the soundboard does not need to load audio from
another website.

Source: https://opengameart.org/content/silly-sound-effects

Included clips: `blah.mp3`, `bloop.mp3`, `blung.mp3`, `booleh.mp3`, `plup.mp3`,
and `uah.mp3`.
